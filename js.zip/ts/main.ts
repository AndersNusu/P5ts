function setup(): void {
  let Xcanvas: number;
  let Ycanvas: number;
  Xcanvas = 100;
  Ycanvas = 100;
  createCanvas(Xcanvas, Ycanvas);
  line(10, 10, 50, 50);
}
