"use strict";
function setup() {
    let Xcanvas;
    let Ycanvas;
    Xcanvas = 100;
    Ycanvas = 100;
    createCanvas(Xcanvas, Ycanvas);
    line(10, 10, 50, 50);
}
